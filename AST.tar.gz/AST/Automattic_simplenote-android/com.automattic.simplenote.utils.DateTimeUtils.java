date time util 
get date text 
com automatt simplenot util android app activ java util calendar date time util string get date text activ activ calendar note date note date calendar get instanc get time milli char sequenc date text android text format date util get rel date time string activ note date get time milli android text format date util format abbrev date text string 
creat onko 2016 