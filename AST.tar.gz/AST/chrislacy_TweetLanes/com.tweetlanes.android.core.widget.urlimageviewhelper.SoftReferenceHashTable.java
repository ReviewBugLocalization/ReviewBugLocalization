soft refer hash tabl 
put get remov 
com tweetlan android core widget urlimageviewhelp java lang ref soft refer java util hashtabl soft refer hash tabl hashtabl soft refer tabl hashtabl soft refer put key valu soft refer old tabl put key soft refer valu old old get get key soft refer val tabl get key val ret val get ret tabl remov key ret remov soft refer tabl remov get 
