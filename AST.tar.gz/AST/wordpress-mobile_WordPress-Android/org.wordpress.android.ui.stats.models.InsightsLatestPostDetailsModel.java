insight latest post detail model 
insight latest post detail model get blog get post view count 
org wordpress android stat model org json json except org json json object insight latest post detail model base stat model string blog view insight latest post detail model string blog json object respons json except blog blog view respons get int string get blog blog get post view count view 
