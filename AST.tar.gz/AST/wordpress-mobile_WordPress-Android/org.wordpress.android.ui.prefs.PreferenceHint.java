prefer hint 
hint get hint set hint 
org wordpress android pref prefer hint hint string get hint set hint string hint 
