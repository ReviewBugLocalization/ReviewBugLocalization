gener callback 
callback 
org wordpress android util gener callback callback 
