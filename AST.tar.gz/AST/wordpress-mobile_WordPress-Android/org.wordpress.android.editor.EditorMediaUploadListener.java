editor media upload listen 
media upload succeed media upload progress media upload fail galleri media upload succeed 
org wordpress android editor org wordpress android util helper media file editor media upload listen media upload succeed string local media file media file media upload progress string local progress media upload fail string local string error messag galleri media upload succeed galleri string remot remain 
