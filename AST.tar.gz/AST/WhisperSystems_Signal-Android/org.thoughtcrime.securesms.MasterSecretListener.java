master secret listen 
master secret clear 
org thoughtcrim securesm master secret listen master secret clear 
