secur event listen 
secur event listen secur event 
org thoughtcrim securesm push android content context org thoughtcrim securesm crypto secur event org whispersystem signalservic api signal servic messag sender org whispersystem signalservic api push signal servic address secur event listen signal servic messag sender event listen string tag secur event listen get simpl name context context secur event listen context context context context get applic context overrid secur event signal servic address text secur address secur event broadcast secur updat event context 
