giphi respons 
get data 
org thoughtcrim securesm giph model com fasterxml jackson annot json properti java util list giphi respons json properti list giphi imag data list giphi imag get data data 
