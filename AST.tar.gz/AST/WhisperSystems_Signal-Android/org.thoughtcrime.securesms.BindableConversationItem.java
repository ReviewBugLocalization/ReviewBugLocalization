bindabl convers item 
bind get messag record 
org thoughtcrim securesm android support annot non null org thoughtcrim securesm crypto master secret org thoughtcrim securesm databas model messag record org thoughtcrim securesm recipi recipi java util local java util set bindabl convers item unbind bind non null master secret master secret non null messag record messag record non null local local non null set messag record batch select non null recipi recipi messag record get messag record 
