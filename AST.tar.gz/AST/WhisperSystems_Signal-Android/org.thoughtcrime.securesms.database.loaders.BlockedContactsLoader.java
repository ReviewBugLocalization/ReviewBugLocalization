block contact loader 
block contact loader get cursor 
org thoughtcrim securesm databas loader android content context android databas cursor org thoughtcrim securesm databas databas factori org thoughtcrim securesm util abstract cursor loader block contact loader abstract cursor loader block contact loader context context context overrid cursor get cursor databas factori get recipi prefer databas get context get block 
