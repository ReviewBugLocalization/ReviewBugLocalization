parcel util 
serial deseri deseri 
org thoughtcrim securesm util android parcel android parcel parcel util serial parcel parceabl parcel parcel parcel obtain parceabl write parcel parcel byte parcel marshal parcel recycl byte parcel deseri byte parcel parcel parcel obtain parcel unmarshal byte byte length parcel set data posit parcel deseri byte parcel creator creator parcel parcel deseri byte creator creat parcel parcel 
