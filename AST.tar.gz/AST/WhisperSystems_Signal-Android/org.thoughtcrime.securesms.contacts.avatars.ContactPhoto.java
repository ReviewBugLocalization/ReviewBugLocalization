contact photo 
drawabl drawabl call card 
org thoughtcrim securesm contact avatar android content context android graphic drawabl drawabl contact photo drawabl drawabl context context color drawabl drawabl context context color invert drawabl call card context context 
