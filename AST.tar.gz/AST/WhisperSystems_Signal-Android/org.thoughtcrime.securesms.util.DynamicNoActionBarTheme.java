dynam action bar theme 
get select theme 
org thoughtcrim securesm util android app activ org thoughtcrim securesm dynam action bar theme dynam theme overrid get select theme activ activ string theme text secur prefer get theme activ theme equal style text secur dark action bar style text secur light action bar 
