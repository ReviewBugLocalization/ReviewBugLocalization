migrat 
add preview column 
com fsck mailstor migrat android databas sqlite lite databas android databas sqlite lite except migrat add preview column lite databas exec sql lite except string start 
