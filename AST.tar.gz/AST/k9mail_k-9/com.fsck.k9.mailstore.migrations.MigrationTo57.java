migrat 
fix data locat multipart part 
com fsck mailstor migrat android databas sqlite lite databas migrat databas child part contain data fix data locat multipart part lite databas exec sql child part contain data databas 
