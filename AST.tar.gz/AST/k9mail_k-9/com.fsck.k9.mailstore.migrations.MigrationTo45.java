migrat 
chang thread index 
com fsck mailstor migrat android databas sqlite lite databas android databas sqlite lite except migrat chang thread index lite databas exec sql exec sql exec sql exec sql exec sql exec sql lite except get messag start 
