file helper test 
test sanit test sanit test sanit test sanit test sanit check sanit 
com fsck helper android support test runner android unit org junit test org junit runner run junit framework assert assert equal run android unit file helper test test test sanit check sanit test test sanit check sanit test test sanit check sanit test test sanit check sanit test test sanit check sanit check sanit string expect string actual assert equal expect file helper sanit filenam actual 
