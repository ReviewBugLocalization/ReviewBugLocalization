base account 
get email set email get descript set descript get uuid 
com fsck base account string get email set email string email string get descript set descript string descript string get uuid 
