migrat 
add delet column 
com fsck mailstor migrat android databas sqlite lite databas android databas sqlite lite except migrat add delet column lite databas exec sql lite except string start 
