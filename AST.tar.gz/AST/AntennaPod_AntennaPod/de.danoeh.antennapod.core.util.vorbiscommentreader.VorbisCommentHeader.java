vorbi comment header 
vorbi comment header string get vendor string get user comment length 
danoeh antennapod core util vorbiscommentread vorbi comment header string vendor string user comment length vorbi comment header string vendor string user comment length vendor string vendor string user comment length user comment length overrid string string vendor string user comment length string get vendor string vendor string get user comment length user comment length 
