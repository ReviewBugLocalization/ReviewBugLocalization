load indic view holder 
load indic view holder set load progress visibl 
org mariotaku twider view holder android support widget recycl view android view view org mariotaku twider load indic view holder recycl view view holder view load progress load indic view holder view view view load progress view find view load _progress set load progress visibl visibl load progress set visibl visibl view visibl view gone 
creat mariotaku 