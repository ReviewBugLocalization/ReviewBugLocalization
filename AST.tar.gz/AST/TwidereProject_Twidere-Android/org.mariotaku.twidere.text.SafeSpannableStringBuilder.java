safe spannabl string builder 
safe spannabl string builder set span 
org mariotaku twider text android text spannabl string builder org mariotaku twider util check util org mariotaku twider util twider string util safe spannabl string builder spannabl string builder safe spannabl string builder char sequenc sourc sourc twider string util fix shi overrid set span object start end flag check util check rang start end set span start end flag 
creat ningyuan 2015 silent ignor 