direct messag resourc 
send fanfou direct messag send fanfou direct messag 
org mariotaku microblog librari fanfou api org mariotaku restfu annot method post org mariotaku restfu annot param param org mariotaku microblog librari micro blog except org mariotaku microblog librari twitter model direct messag direct messag resourc post direct messag send fanfou direct messag param string user param string text param string repli micro blog except post direct messag send fanfou direct messag param string user param string text micro blog except 
creat mariotaku 