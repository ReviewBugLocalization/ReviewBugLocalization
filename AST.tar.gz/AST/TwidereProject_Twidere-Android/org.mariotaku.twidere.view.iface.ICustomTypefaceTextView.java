custom typefac text view 
none 
org mariotaku twider view ifac custom typefac text view 
twider twitter client android copyright 2012 2015 mariotaku lee mariotaku lee gmail com program free softwar redistribut modifi term gnu gener public licens publish free softwar foundat either version licens option later version program distribut hope use without warranti without even impli warranti merchant fit particular purpos see gnu gener public licens detail receiv copi gnu gener public licens along program see http www gnu org licens creat mariotaku 