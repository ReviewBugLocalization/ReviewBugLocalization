glide set 
none 
danoeh antennapod core glide com bumptech glide load engin disk cach strategi glide set disk cach strategi disk cach strategi disk cach strategi 
set antenna pod use variou glide option 