task callback 
get automat download algorithm get episod cach cleanup algorithm 
danoeh antennapod core danoeh antennapod core storag automat download algorithm danoeh antennapod core storag episod cleanup algorithm task callback automat download algorithm get automat download algorithm episod cleanup algorithm get episod cach cleanup algorithm 
callback task class storag modul return client implement automat download algorithm interfac return client implement episod cach cleanup algorithm interfac 