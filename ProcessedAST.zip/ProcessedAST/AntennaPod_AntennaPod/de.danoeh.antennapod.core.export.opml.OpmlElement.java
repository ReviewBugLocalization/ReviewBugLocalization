opml element 
opml element get text set text get xml url set xml url get html url set html url get type set type 
danoeh antennapod core export opml opml element string text string xml url string html url string type opml element string get text text set text string text text text string get xml url xml url set xml url string xml url xml url xml url string get html url html url set html url string html url html url html url string get type type set type string type type type 
repres singl feed opml file 