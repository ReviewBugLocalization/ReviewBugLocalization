feedtitl compar 
compar 
danoeh antennapod core util danoeh antennapod core feed feed java util compar feedtitl compar compar feed overrid compar feed lh feed rh lh get titl compar ignor case rh get titl 
compar titl two feed sort 