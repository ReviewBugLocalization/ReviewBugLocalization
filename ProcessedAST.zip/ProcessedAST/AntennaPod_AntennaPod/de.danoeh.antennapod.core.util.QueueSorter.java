queue sorter 
sort 
danoeh antennapod core util android content context java util compar danoeh antennapod core feed feed item danoeh antennapod core feed feed media danoeh antennapod core storag writer queue sorter enum rule sort context context rule rule broadcast updat compar feed item compar rule episod titl asc compar episod titl desc compar date asc compar date desc compar durat asc compar durat desc compar feed titl asc compar feed titl desc compar compar writer sort queue compar broadcast updat 
provid method sort queue accord rule 