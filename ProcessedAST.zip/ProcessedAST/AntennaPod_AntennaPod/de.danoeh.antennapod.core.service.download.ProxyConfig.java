proxi config 
direct http proxi config 
danoeh antennapod core servic download android support annot nullabl java net proxi proxi config proxi type type nullabl string host port nullabl string usernam nullabl string password default port proxi config direct proxi config proxi type direct proxi config http string host port string usernam string password proxi config proxi type http host port usernam password proxi config proxi type type string host port string usernam string password type type host host port port usernam usernam password password 
