simpl chapter 
simpl chapter get chapter type updat 
danoeh antennapod core feed simpl chapter chapter chaptertyp simplechapt simpl chapter start string titl feed item item string link start titl item link overrid get chapter type chaptertyp simplechapt updat simpl chapter updat start start titl titl titl link link link 
