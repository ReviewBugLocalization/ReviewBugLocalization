export writer 
write document file extens 
danoeh antennapod core export java except java writer java util list danoeh antennapod core feed feed export writer write document list feed feed writer writer illeg argument except illeg state except except string file extens 
licens apach licens version licens may use file except complianc licens may obtain copi licens http www apach org licens licens unless requir applic law agre write softwar distribut licens distribut basi without warranti condit kind either express impli see licens specif languag govern permiss limit licens 