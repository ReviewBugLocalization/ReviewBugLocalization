custom control dialog fragment 
creat control dialog 
danoeh antennapod fragment android content context android bundl android support app media rout control dialog android support app media rout control dialog fragment danoeh antennapod dialog custom control dialog custom control dialog fragment media rout control dialog fragment overrid media rout control dialog creat control dialog context context bundl save instanc state custom control dialog context 
