tag header 
tag header string get version 
danoeh antennapod core util 3reader model tag header header version flag tag header string size version flag size version version flag flag overrid string string version flag size get version version 
