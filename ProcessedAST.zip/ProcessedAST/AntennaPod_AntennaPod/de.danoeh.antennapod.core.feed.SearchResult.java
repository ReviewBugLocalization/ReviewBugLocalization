search result 
search result get compon get subtitl set subtitl get valu 
danoeh antennapod core feed search result feed compon compon string subtitl valu search result feed compon compon valu string subtitl compon compon valu valu subtitl subtitl feed compon get compon compon string get subtitl subtitl set subtitl string subtitl subtitl subtitl get valu valu 
addit inform found higher valu mean import 