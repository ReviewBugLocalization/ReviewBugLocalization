file name gener 
file name gener gener file name gener long 
danoeh antennapod core util java util array file name gener illeg charact array sort illeg charact file name gener string gener file name string string string builder builder string builder string length string char array binari search illeg charact builder append builder string replac first gener long string str str hash code 
gener valid filenam given string method return new string contain illeg charact given string 