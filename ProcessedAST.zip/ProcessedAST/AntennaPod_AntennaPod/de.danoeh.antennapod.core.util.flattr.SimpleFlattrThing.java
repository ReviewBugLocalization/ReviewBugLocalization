simpl flattr thing 
simpl flattr thing get titl get payment link get flattr statu 
danoeh antennapod core util flattr simpl flattr thing flattr thing simpl flattr thing string titl string url flattr statu statu titl titl url url statu statu string get titl titl string get payment link url flattr statu get flattr statu statu string titl string url flattr statu statu 
simpl flattr thing trivial implement flattr thing interfac 