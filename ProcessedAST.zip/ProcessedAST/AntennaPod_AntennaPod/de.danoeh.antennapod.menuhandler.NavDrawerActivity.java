nav drawer activ 
drawer open 
danoeh antennapod menuhandl nav drawer activ drawer open 
defin use method activ navig drawer 