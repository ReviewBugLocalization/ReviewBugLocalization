gener util 
add payment link 
test antennapod util syndic feedgener org xmlpull xml serial java except gener util add payment link xml serial xml string payment link namespac except string namespac xml start tag xml attribut xml attribut xml attribut payment link xml attribut xml end tag 
util method feed gener 