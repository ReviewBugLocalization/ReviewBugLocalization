synd element 
synd element get namespac get name 
danoeh antennapod core syndic namespac synd element string name namespac namespac synd element string name namespac namespac name name namespac namespac namespac get namespac namespac string get name name 
defin xml element push tagstack 