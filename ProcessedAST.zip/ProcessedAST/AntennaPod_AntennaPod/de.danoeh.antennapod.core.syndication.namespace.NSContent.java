content 
handl element start handl element end 
danoeh antennapod core syndic namespac org xml sax attribut danoeh antennapod core syndic handler handler state content namespac string nstag string nsuri string encod overrid synd element handl element start string local name handler state state attribut attribut synd element local name overrid handl element end string local name handler state state encod equal local name state get current item state get content buf state get current item set content encod state get content buf string 
