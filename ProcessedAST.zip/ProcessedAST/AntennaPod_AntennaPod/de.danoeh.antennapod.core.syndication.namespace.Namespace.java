namespac 
handl element start handl element end 
danoeh antennapod core syndic namespac danoeh antennapod core syndic handler handler state org xml sax attribut namespac string nstag string nsuri synd element handl element start string local name handler state state attribut attribut handl element end string local name handler state state 
call feedhandl start element detect namespac element return synd element push onto stack call feedhandl end element detect namespac element return true namespac handl element fals ignor 