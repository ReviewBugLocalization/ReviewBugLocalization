applic callback 
get applic instanc get storag error activ 
danoeh antennapod core android app applic android content context android content intent applic callback applic get applic instanc intent get storag error activ context context 
callback relat applic gener return non null instanc applic class return non null intent start storag error activ 