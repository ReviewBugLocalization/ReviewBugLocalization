automat download algorithm 
auto download undownload item 
danoeh antennapod core storag android content context automat download algorithm runnabl auto download undownload item context context 
look undownload episod request download network avail devic charg user allow auto download batteri free space episod cach method execut intern singl thread executor param context use access return runnabl submit executor servic 