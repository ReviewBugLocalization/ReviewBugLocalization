gpodnet devic 
gpodnet devic string string string get get caption get type get subscript 
danoeh antennapod core gpoddernet model android support annot non null gpodnet devic string string caption devic type type subscript gpodnet devic non null string string caption string type subscript caption caption type devic type string type subscript subscript overrid string string caption type subscript enum devic type devic type string string desktop laptop mobil server overrid string string string lower case string get string get caption caption devic type get type type get subscript subscript 
