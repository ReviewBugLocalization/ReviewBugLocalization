flattr servic creator 
get servic delet flattr servic 
danoeh antennapod core util flattr android util log org shredzon flattr flattr factori org shredzon flattr flattr servic org shredzon flattr oauth access token danoeh antennapod core build config flattr servic creator string tag flattr servic flattr servic flattr servic get servic access token token flattr servic flattr servic flattr factori get instanc creat flattr servic token flattr servic delet flattr servic build config debug log tag flattr servic 
ensur one instanc flattr servic class exist time 