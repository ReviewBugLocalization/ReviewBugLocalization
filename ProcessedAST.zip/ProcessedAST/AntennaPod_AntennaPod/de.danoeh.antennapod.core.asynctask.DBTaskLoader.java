task loader 
task loader stop load start load 
danoeh antennapod core asynctask android content context android support content async task loader task loader async task loader task loader context context context overrid stop load stop load cancel load overrid start load start load forc load 
subclass async task loader made load data one class class provid use default implement would otherwis alway necessari interact class async task loader accord http code googl com android issu detail 14944 call manual 