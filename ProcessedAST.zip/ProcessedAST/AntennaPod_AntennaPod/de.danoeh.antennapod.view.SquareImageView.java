squar imag view 
squar imag view squar imag view squar imag view measur 
danoeh antennapod view android content context android util attribut set android widget imag view squar imag view imag view squar imag view context context context squar imag view context context attribut set attr context attr squar imag view context context attribut set attr def style context attr def style overrid measur width measur spec height measur spec measur width measur spec height measur spec width get measur width set measur dimens width width 
http stackoverflow com 19449488 6839 