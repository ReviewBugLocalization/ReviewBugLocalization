gpodnet callback 
gpodnet enabl get gpodnet sync servic error notif pend intent 
danoeh antennapod core android app pend intent android content context gpodnet callback gpodnet enabl pend intent get gpodnet sync servic error notif pend intent context context 
callback relat gpodder net integr core modul return true gpodder net integr activ fals otherwis return pend intent error notif gpodnet sync servic pend intent may implement specif return pend intent notif null gpodder net integr disabl gpodnet enabl fals 