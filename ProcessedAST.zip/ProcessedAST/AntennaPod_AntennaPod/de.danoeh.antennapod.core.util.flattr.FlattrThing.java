flattr thing 
get titl get payment link get flattr statu 
danoeh antennapod core util flattr flattr thing string get titl string get payment link flattr statu get flattr statu 
