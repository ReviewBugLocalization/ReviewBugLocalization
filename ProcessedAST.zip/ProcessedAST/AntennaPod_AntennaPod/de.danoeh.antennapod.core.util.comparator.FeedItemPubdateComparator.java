feed item pubdat compar 
compar 
danoeh antennapod core util compar danoeh antennapod core feed feed item java util compar feed item pubdat compar compar feed item overrid compar feed item lh feed item rh rh get pub date compar lh get pub date 
compar pub date two feed item sort return new instanc compar revers order public static feed item pubdat compar new instanc feed item pubdat compar 