
none 
danoeh antennapod core util android content context danoeh antennapod core 
util class download error return download error associ code get machin readabl code get human readabl string 