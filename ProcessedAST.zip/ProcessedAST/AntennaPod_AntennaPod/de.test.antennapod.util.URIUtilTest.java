uri util test 
test get uri request url encod test get uri request url encod 
test antennapod util android test android test case danoeh antennapod core util uri util uri util test android test case test get uri request url encod string test url assert equal test url uri util get uri request url test url string test get uri request url encod string test url string expect assert equal expect uri util get uri request url test url string 
test class uri util 