power util 
power util devic charg 
danoeh antennapod core util android content context android content intent android content intent filter android batteri manag power util string tag power util devic charg context context intent filter filter intent filter intent action batteri chang intent batteri statu context regist receiv filter statu batteri statu get int extra batteri manag extra statu statu batteri manag batteri statu charg statu batteri manag batteri statu full 
creat tom return true devic charg http develop android com train monitor devic state batteri monitor html 