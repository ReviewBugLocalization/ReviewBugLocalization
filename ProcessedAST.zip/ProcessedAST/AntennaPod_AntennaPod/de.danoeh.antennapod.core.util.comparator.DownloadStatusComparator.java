download statu compar 
compar 
danoeh antennapod core util compar danoeh antennapod core servic download download statu java util compar download statu compar compar download statu overrid compar download statu lh download statu rh rh get complet date compar lh get complet date 
compar complet date two downloadstatu object 