task callback impl 
get automat download algorithm get episod cach cleanup algorithm 
danoeh antennapod config danoeh antennapod core task callback danoeh antennapod core prefer user prefer danoeh antennapod core storag download algorithm danoeh antennapod core storag automat download algorithm danoeh antennapod core storag episod cleanup algorithm task callback impl task callback overrid automat download algorithm get automat download algorithm download algorithm overrid episod cleanup algorithm get episod cach cleanup algorithm user prefer get episod cleanup algorithm 
