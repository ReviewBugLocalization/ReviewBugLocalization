unsupport feedtyp except 
unsupport feedtyp except unsupport feedtyp except get type get root element get messag 
danoeh antennapod core syndic handler danoeh antennapod core syndic handler type getter type unsupport feedtyp except except serial version uid type getter type type string root element unsupport feedtyp except type type type type unsupport feedtyp except type type string root element type type root element root element type getter type get type type string get root element root element overrid string get messag type type getter type invalid type 
