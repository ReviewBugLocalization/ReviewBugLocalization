intent util 
callabl 
danoeh antennapod core util android content context android content intent android content packag manag android content resolv info java util list intent util callabl context context intent intent list resolv info list context get packag manag queri intent activ intent packag manag match default resolv info info list info activ info export 
check least one export activ perform intent 