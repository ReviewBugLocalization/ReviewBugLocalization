frame header 
frame header string 
danoeh antennapod core util 3reader model frame header header flag frame header string size flag size flag flag overrid string string string format integ binari string flag integ binari string size 
