swipe gestur 
swipe left right swipe right left 
danoeh antennapod view swipe gestur swipe left right swipe right left 
