uri util 
uri util get uri request url 
danoeh antennapod core util android util log java net malform url except java net uri java net uri syntax except java net url danoeh antennapod core build config uri util string tag uri util uri get uri request url string sourc uri sourc uri syntax except build config debug log tag url url url sourc uri url get protocol url get user info url get host url get port url get path url get queri url get ref malform url except illeg argument except 
util method deal url encod tri without encod uri 