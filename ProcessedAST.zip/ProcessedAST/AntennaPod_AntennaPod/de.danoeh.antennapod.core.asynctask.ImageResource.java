imag resourc 
get imag locat 
danoeh antennapod core asynctask imag resourc string get imag locat 
class implement interfac provid access imag resourc load picasso librari return locat imag null imag avail locat either url local path 