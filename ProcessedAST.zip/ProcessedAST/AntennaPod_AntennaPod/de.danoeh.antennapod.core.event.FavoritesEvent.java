favorit event 
favorit event ad remov string 
danoeh antennapod core event org apach common lang builder string builder org apach common lang builder string style danoeh antennapod core feed feed item favorit event enum action action action feed item item favorit event action action feed item item action action item item favorit event ad feed item item favorit event action ad item favorit event remov feed item item favorit event action remov item overrid string string string builder string style short prefix style append action append item string 
