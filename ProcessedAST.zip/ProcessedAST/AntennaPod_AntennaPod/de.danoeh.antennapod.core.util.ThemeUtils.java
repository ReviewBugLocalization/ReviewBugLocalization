theme util 
get select background color 
danoeh antennapod core util android util log danoeh antennapod core danoeh antennapod core prefer user prefer theme util string tag get select background color theme user prefer get theme theme style theme antenna pod dark color select _background _color _dark theme style theme antenna pod light color select _background _color _light log tag color select _background _color _light 
