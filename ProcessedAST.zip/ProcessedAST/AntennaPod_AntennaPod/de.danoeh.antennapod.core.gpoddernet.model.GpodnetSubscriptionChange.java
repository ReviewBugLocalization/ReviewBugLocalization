gpodnet subscript chang 
gpodnet subscript chang string get ad get remov get timestamp 
danoeh antennapod core gpoddernet model android support annot non null java util list gpodnet subscript chang list string ad list string remov timestamp gpodnet subscript chang non null list string ad non null list string remov timestamp ad ad remov remov timestamp timestamp overrid string string ad string remov string timestamp list string get ad ad list string get remov remov get timestamp timestamp 
