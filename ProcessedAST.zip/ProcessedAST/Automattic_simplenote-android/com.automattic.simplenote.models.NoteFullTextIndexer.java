note full text index 
index 
com automatt simplenot model com simperium client full text index java util hash map java util map note full text index full text index index note suppress warn string comma string index note full text index overrid map string string index string key note note map string string valu hash map key length valu put index note get titl valu put index note get content valu 
