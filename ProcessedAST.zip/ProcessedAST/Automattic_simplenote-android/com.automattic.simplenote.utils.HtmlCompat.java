html compat 
html 
com automatt simplenot util android build android text html android text span html compat suppress warn span html string sourc build version sdk int build version code html html sourc html html mode legaci html html sourc 
