note editor view pager 
note editor view pager intercept touch event touch event set page enabl 
com automatt simplenot widget android content context android support view view pager android util attribut set android view motion event note editor view pager view pager enabl note editor view pager context context attribut set attr context attr enabl overrid intercept touch event motion event event enabl intercept touch event event overrid touch event motion event event enabl touch event event set page enabl enabl enabl enabl 
