simplenot linkifi 
add link 
com automatt simplenot util android text spannabl android text spannabl string android text util linkifi android widget text view java util regex pattern simplenot linkifi string simplenot scheme pattern simplenot link pattern pattern compil add link text view text mask mask char sequenc text get text spannabl link linkifi add link spannabl mask linkifi add link spannabl simplenot link pattern simplenot scheme link spannabl string spannabl string valu linkifi add link mask text set text 
creat dan work linkifi add link set movement method 