note count index 
note count index index 
com automatt simplenot model com simperium client bucket com simperium client bucket schema index com simperium client bucket schema index java util array list java util list note count index index tag bucket note note bucket note count index bucket note note bucket note bucket note bucket overrid list index index tag tag list index index array list count note tag note bucket tag get simperium key count index add index tag note count index name count index 
creat beaucollin 