context util 
read css file 
com automatt simplenot util android content context java buffer reader java except java input stream java input stream reader context util string read css file context context string css input stream stream buffer reader reader string builder builder string builder string line stream context get resourc get asset open css reader buffer reader input stream reader stream line reader read line builder append line builder append builder string except stream stream close except ignor reader reader close except ignor 
