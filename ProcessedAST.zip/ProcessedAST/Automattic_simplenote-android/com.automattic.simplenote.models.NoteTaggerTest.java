note tagger test 
test url encod tag key 
com automatt simplenot model junit framework test case com simperium client bucket note tagger test test case test url encod tag key except bucket note note bucket mock bucket build bucket note schema bucket tag tag bucket mock bucket build bucket tag schema note note note bucket new object note set tag string note tagger tagger note tagger tag bucket tagger save object note bucket note assert equal tag bucket count tag special tag bucket get object assert null special assert equal special get name 
two tag écial url encod 9cial 