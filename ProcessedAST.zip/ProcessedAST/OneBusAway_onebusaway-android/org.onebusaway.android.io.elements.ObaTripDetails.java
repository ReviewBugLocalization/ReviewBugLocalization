oba trip detail 
get schedul get statu 
org onebusaway android element oba trip detail oba element oba trip schedul get schedul oba trip statu get statu 
copyright 2010 paul watt paulcwatt gmail com licens apach licens version licens may use file except complianc licens may obtain copi licens http www apach org licens licens unless requir applic law agre write softwar distribut licens distribut basi without warranti condit kind either express impli see licens specif languag govern permiss limit licens return detail trip schedul null schedul includ return detail trip statu null statu includ 