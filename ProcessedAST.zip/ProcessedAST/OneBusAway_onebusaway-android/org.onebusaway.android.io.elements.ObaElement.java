oba element 
get 
org onebusaway android element oba element string get 
copyright 2010 paul watt paulcwatt gmail com licens apach licens version licens may use file except complianc licens may obtain copi licens http www apach org licens licens unless requir applic law agre write softwar distribut licens distribut basi without warranti condit kind either express impli see licens specif languag govern permiss limit licens base interfac element author paul watt paulcwatt gmail com return return element 